import pymysql
import matplotlib.pyplot as plt

C=pymysql.connect(host="10.1.120.50",user="guest",db="models")
c=C.cursor()
x=[]
y=[]
c.execute("select * from dat")
P =c.fetchall()
for a,b in P:
	x.append(a)
	y.append(b)

fig=plt.figure()
ax=fig.add_axes([0,0,1,1])
ax.scatter(x, y)
plt.show()
