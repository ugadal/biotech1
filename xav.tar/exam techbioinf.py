import matplotlib.pyplot as plt
import pymysql
conn = pymysql.connect(
        host='10.1.120.50',
        user='guest',
        db='models',
        )
variable=conn.cursor()

variable.execute("select * from dat")
X=[]
Y=[]
for l in variable.fetchall():
    x,y = l
    X.append(x)
    Y.append(y)

# ~ print ("X",X)
# ~ print ("Y",Y)

    
plt.scatter(X, Y)
# ~ plt.rcParams.update({'figure.figsize':(10,8), 'figure.dpi':100})
plt.title('Un petit titre')
plt.xlabel('axe X')
plt.ylabel('axe Y')
plt.show()
