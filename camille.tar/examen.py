import pymysql
from matplotlib import pyplot

C=pymysql.connect(host="10.1.120.50", db="models", user="guest")
c=C.cursor()
c.execute("SELECT x,y FROM dat")
X=c.fetchall()


x = [a for a, b in X]
y = [b for a, b in X]

pyplot.scatter(x, y)
pyplot.show()

